package net.lootbeams.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonSyntaxException;
import net.fabricmc.loader.api.FabricLoader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;
import java.util.LinkedHashSet;

/**
 * Plain JSON config, no external config-library dependency on purpose:
 * it keeps Lootbeams from ever fighting another mod over a shared config
 * framework, and means there is nothing here that can conflict with
 * Sodium / Entity Culling / Iris / etc. (this mod touches none of their code).
 */
public class LootbeamsConfig {

    private static final Logger LOGGER = LoggerFactory.getLogger("lootbeams/config");
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().disableHtmlEscaping().create();
    private static final Path PATH = FabricLoader.getInstance().getConfigDir().resolve("lootbeams.json");

    public static LootbeamsConfig INSTANCE = new LootbeamsConfig();

    // ---- General ----
    public boolean enabled = true;
    /** Hard cap, in blocks, beyond which nothing is drawn at all (perf safety net). */
    public double maxRenderDistance = 48.0;

    // ---- Outline ----
    public Outline outline = new Outline();

    public static class Outline {
        public boolean enabled = true;
        /** If true, the outline is drawn through blocks/walls as well. */
        public boolean throughWalls = true;
        public float lineWidth = 1.5f;
        /** How far the box is inflated around the item's real hitbox, in blocks. */
        public float expand = 0.05f;
        /** Alpha used for the portion of the outline that is directly visible. */
        public float visibleAlpha = 1.0f;
        /** Alpha used for the portion that is only visible because throughWalls=true. */
        public float xrayAlpha = 0.35f;
    }

    // ---- Beam ----
    public Beam beam = new Beam();

    public static class Beam {
        public boolean enabled = true;
        public boolean throughWalls = true;
        public float width = 0.25f;
        public float height = 60.0f;
        public float alpha = 0.5f;
        /** The beam gently rotates; set to 0 to make it static. */
        public float spinDegreesPerSecond = 20.0f;
    }

    // ---- Colors ----
    /** Hex color ("#RRGGBB") per vanilla item rarity name (COMMON/UNCOMMON/RARE/EPIC or custom datapack rarities). */
    public Map<String, String> rarityColors = defaultRarityColors();

    /** Per-item hex color override, keyed by item id, e.g. "minecraft:netherite_ingot". Overrides rarity color. */
    public Map<String, String> itemColorOverrides = defaultItemOverrides();

    // ---- Filtering ----
    /** If true, ONLY items in `whitelist` are ever highlighted. If false, everything except `blacklist` is highlighted. */
    public boolean whitelistMode = false;
    public Set<String> whitelist = new LinkedHashSet<>();
    public Set<String> blacklist = defaultBlacklist();

    private static Map<String, String> defaultRarityColors() {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("COMMON", "#FFFFFF");
        map.put("UNCOMMON", "#FFFF55");
        map.put("RARE", "#55FFFF");
        map.put("EPIC", "#FF55FF");
        return map;
    }

    private static Map<String, String> defaultItemOverrides() {
        Map<String, String> map = new LinkedHashMap<>();
        map.put("minecraft:netherite_ingot", "#B24544");
        map.put("minecraft:diamond", "#4DE6E0");
        map.put("minecraft:nether_star", "#FFD966");
        return map;
    }

    private static Set<String> defaultBlacklist() {
        Set<String> set = new LinkedHashSet<>();
        set.add("minecraft:arrow");
        set.add("minecraft:snowball");
        set.add("minecraft:egg");
        set.add("minecraft:experience_bottle");
        return set;
    }

    public static void load() {
        if (!Files.exists(PATH)) {
            INSTANCE = new LootbeamsConfig();
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(PATH, StandardCharsets.UTF_8)) {
            LootbeamsConfig loaded = GSON.fromJson(reader, LootbeamsConfig.class);
            INSTANCE = loaded != null ? loaded : new LootbeamsConfig();
        } catch (IOException | JsonSyntaxException e) {
            LOGGER.error("Failed to read lootbeams.json, falling back to defaults", e);
            INSTANCE = new LootbeamsConfig();
        }
        // Backfill any fields missing from an older config file on disk.
        save();
    }

    public static void save() {
        try {
            Files.createDirectories(PATH.getParent());
            try (Writer writer = Files.newBufferedWriter(PATH, StandardCharsets.UTF_8)) {
                GSON.toJson(INSTANCE, writer);
            }
        } catch (IOException e) {
            LOGGER.error("Failed to write lootbeams.json", e);
        }
    }
}
