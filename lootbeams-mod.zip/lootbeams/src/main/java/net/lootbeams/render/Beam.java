package net.lootbeams.render;

import net.minecraft.client.render.VertexConsumer;
import org.joml.Matrix4f;

/**
 * Draws a soft vertical beam as four crossed, untextured quads (like a stripped-down
 * beacon beam) fading from the configured alpha at the base to fully transparent at
 * the top. Cull is disabled on the pipeline so winding order doesn't matter.
 */
final class Beam {

    private Beam() {}

    static void draw(Matrix4f pose, VertexConsumer buf, float r, float g, float b,
                      float baseAlpha, float width, float height, float spinDegrees) {
        float half = width / 2f;

        for (int i = 0; i < 4; i++) {
            float angle = (float) Math.toRadians(spinDegrees + i * 45.0);
            float cos = (float) Math.cos(angle);
            float sin = (float) Math.sin(angle);

            float x1 = -half * cos, z1 = -half * sin;
            float x2 = half * cos, z2 = half * sin;

            buf.vertex(pose, x1, 0, z1).color(r, g, b, baseAlpha);
            buf.vertex(pose, x2, 0, z2).color(r, g, b, baseAlpha);
            buf.vertex(pose, x2, height, z2).color(r, g, b, 0f);
            buf.vertex(pose, x1, height, z1).color(r, g, b, 0f);
        }
    }
}
