package net.lootbeams.render;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import com.mojang.blaze3d.platform.DepthTestFunction;
import com.mojang.blaze3d.vertex.VertexFormat;
import net.minecraft.client.gl.RenderPipelines;
import net.minecraft.client.render.RenderLayer;
import net.minecraft.client.render.RenderPhase;
import net.minecraft.client.render.VertexFormats;
import net.minecraft.util.Identifier;

/**
 * Custom RenderLayers used by Lootbeams.
 *
 * We extend RenderLayer purely to reach its protected static factory method
 * ("of") from our own package - this is the standard, mixin-free way mods
 * define custom render layers. We do NOT touch or extend anything from
 * Sodium / Entity Culling / Iris, and we don't replace any vanilla
 * RenderLayer, so this cannot conflict with those mods: they never see
 * these layers, and these layers never see their code.
 *
 * IMPORTANT: Minecraft's rendering internals (RenderPipeline / DepthTestFunction /
 * RenderPipelines.*_SNIPPET names) changed in 1.21.2 and keep shifting slightly
 * between patches. If this file fails to compile against your exact mappings,
 * open a decompiled RenderLayer.LINES / RenderLayer.getLightning() as a reference
 * (Loom's genSources) and adjust the snippet name / builder calls to match.
 */
public final class LootbeamsRenderLayers {

    private LootbeamsRenderLayers() {}

    private static final Identifier LINES_XRAY_ID = Identifier.of("lootbeams", "outline_lines_xray");
    private static final Identifier LINES_NORMAL_ID = Identifier.of("lootbeams", "outline_lines_normal");
    private static final Identifier BEAM_XRAY_ID = Identifier.of("lootbeams", "beam_quads_xray");
    private static final Identifier BEAM_NORMAL_ID = Identifier.of("lootbeams", "beam_quads_normal");

    private static final RenderPipeline LINES_XRAY_PIPELINE = RenderPipeline.builder(RenderPipelines.RENDERTYPE_LINES_SNIPPET)
            .withLocation(LINES_XRAY_ID)
            .withDepthWrite(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .build();

    private static final RenderPipeline LINES_NORMAL_PIPELINE = RenderPipeline.builder(RenderPipelines.RENDERTYPE_LINES_SNIPPET)
            .withLocation(LINES_NORMAL_ID)
            .withDepthWrite(false)
            .build();

    // Plain untextured colored quads (no snippet-provided texture sampling), used for the beam.
    // Blending is left at the snippet's default; if beams render fully opaque on your build,
    // add an explicit .withBlendFunction(...) call here (see README troubleshooting section).
    private static final RenderPipeline BEAM_XRAY_PIPELINE = RenderPipeline.builder(RenderPipelines.MATRICES_COLOR_SNIPPET)
            .withLocation(BEAM_XRAY_ID)
            .withVertexFormat(VertexFormats.POSITION_COLOR, VertexFormat.DrawMode.QUADS)
            .withDepthWrite(false)
            .withCull(false)
            .withDepthTestFunction(DepthTestFunction.NO_DEPTH_TEST)
            .build();

    private static final RenderPipeline BEAM_NORMAL_PIPELINE = RenderPipeline.builder(RenderPipelines.MATRICES_COLOR_SNIPPET)
            .withLocation(BEAM_NORMAL_ID)
            .withVertexFormat(VertexFormats.POSITION_COLOR, VertexFormat.DrawMode.QUADS)
            .withDepthWrite(false)
            .withCull(false)
            .build();

    /** Outline lines, drawn normally (occluded by blocks like any world geometry). */
    public static final RenderLayer OUTLINE_LINES_NORMAL = RenderLayer.of(
            "lootbeams_outline_lines_normal",
            1536,
            LINES_NORMAL_PIPELINE,
            RenderLayer.MultiPhaseParameters.builder()
                    .lineWidth(new RenderPhase.LineWidth(java.util.OptionalDouble.empty()))
                    .build(false)
    );

    /** Outline lines, drawn ignoring depth so they show through walls. */
    public static final RenderLayer OUTLINE_LINES_XRAY = RenderLayer.of(
            "lootbeams_outline_lines_xray",
            1536,
            LINES_XRAY_PIPELINE,
            RenderLayer.MultiPhaseParameters.builder()
                    .lineWidth(new RenderPhase.LineWidth(java.util.OptionalDouble.empty()))
                    .build(false)
    );

    /** Beam quads, drawn normally (occluded by blocks). */
    public static final RenderLayer BEAM_QUADS_NORMAL = RenderLayer.of(
            "lootbeams_beam_quads_normal",
            1536,
            BEAM_NORMAL_PIPELINE,
            RenderLayer.MultiPhaseParameters.builder().build(false)
    );

    /** Beam quads, drawn ignoring depth so they show through walls. */
    public static final RenderLayer BEAM_QUADS_XRAY = RenderLayer.of(
            "lootbeams_beam_quads_xray",
            1536,
            BEAM_XRAY_PIPELINE,
            RenderLayer.MultiPhaseParameters.builder().build(false)
    );
}
