package net.lootbeams;

import com.mojang.brigadier.arguments.BoolArgumentType;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandManager;
import net.fabricmc.fabric.api.client.command.v2.ClientCommandRegistrationCallback;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.lootbeams.config.LootbeamsConfig;
import net.lootbeams.render.ItemGlowRenderer;
import net.minecraft.text.Text;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LootbeamsClient implements ClientModInitializer {

    public static final String MOD_ID = "lootbeams";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    @Override
    public void onInitializeClient() {
        LootbeamsConfig.load();

        // AFTER_ENTITIES: fires once solid geometry + entities are drawn but before
        // translucent geometry, which is the same extension point Fabric API itself
        // documents for "draw extra stuff attached to entities/blocks". We do not
        // touch WorldRenderer, chunk building, or any entity renderer, so this cannot
        // step on Sodium's terrain/entity culling pipeline or Entity Culling's mixins.
        WorldRenderEvents.AFTER_ENTITIES.register(ItemGlowRenderer::onRender);

        ClientCommandRegistrationCallback.EVENT.register((dispatcher, registryAccess) ->
                dispatcher.register(ClientCommandManager.literal("lootbeams")
                        .then(ClientCommandManager.literal("reload").executes(ctx -> {
                            LootbeamsConfig.load();
                            ctx.getSource().sendFeedback(Text.literal("[Lootbeams] Config reloaded."));
                            return 1;
                        }))
                        .then(ClientCommandManager.literal("toggle")
                                .then(ClientCommandManager.argument("enabled", BoolArgumentType.bool())
                                        .executes(ctx -> {
                                            boolean value = BoolArgumentType.getBool(ctx, "enabled");
                                            LootbeamsConfig.INSTANCE.enabled = value;
                                            LootbeamsConfig.save();
                                            ctx.getSource().sendFeedback(Text.literal("[Lootbeams] Enabled: " + value));
                                            return 1;
                                        }))
                                .executes(ctx -> {
                                    LootbeamsConfig.INSTANCE.enabled = !LootbeamsConfig.INSTANCE.enabled;
                                    LootbeamsConfig.save();
                                    ctx.getSource().sendFeedback(Text.literal(
                                            "[Lootbeams] Enabled: " + LootbeamsConfig.INSTANCE.enabled));
                                    return 1;
                                }))
                )
        );

        LOGGER.info("Lootbeams initialized. Edit config/lootbeams.json to customize colors, "
                + "the outline, and the beam. Use /lootbeams reload after editing it in-game, "
                + "or /lootbeams toggle to quickly turn the whole mod on/off.");
    }
}
